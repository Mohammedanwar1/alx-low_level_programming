#include <stdio.h>
#include <string.h>

/**
*main - Main function of my project
*
*
*Return: return 0 everytime
*/
int main(void)
{

	char displayed[52];

	strcpy(displayed, "\"Programming is like building a multilingual puzzle");
	puts(displayed);
	return (0);
}
