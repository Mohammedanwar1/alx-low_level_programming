#include "main.h"
/**
*reset_to_98 - reset value of an integer to 98
*@n: parameter targeted
*Return : nothing
*/

void reset_to_98(int *n)
{
*n = 98;
}
