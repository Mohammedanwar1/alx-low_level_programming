#include "main.h"
/**
*mul - function that multipliestwo numbers
*@a: first number
*@b: second number
*Return: returns result
*/

int mul(int a, int b)
{
return (a * b);
}
